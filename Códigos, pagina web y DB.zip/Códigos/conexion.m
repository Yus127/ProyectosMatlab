close all, clear all, clc;

url = 'http://10.48.149.219/Gpo32-E2/addMATLAB.php';
set_param('entrega3E2','SimulationCommand','start')

while 1
    if(strcmp(get_param('entrega3E2','SimulationStatus'), 'paused'))
        tmp_s_x = get_param('entrega3E2/TMP','RuntimeObject');
        tmp = tmp_s_x.OutputPort(1).Data
        pm10_s_x = get_param('entrega3E2/PM10','RuntimeObject');
        pm10 = pm10_s_x.OutputPort(1).Data 
        pm25_s_x = get_param('entrega3E2/PM25','RuntimeObject');
        pm25 = pm25_s_x.OutputPort(1).Data       
        rh_s_x = get_param('entrega3E2/RH','RuntimeObject');
        rh = rh_s_x.OutputPort(1).Data  
        cs_s_x = get_param('entrega3E2/CS','RuntimeObject');
        cs = cs_s_x.OutputPort(1).Data  
        pa_s_x = get_param('entrega3E2/PA','RuntimeObject');
        pa = pa_s_x.OutputPort(1).Data
        response = webwrite(url,'id','null','pm10',pm10, 'pm25', pm25, 'rh', rh, 'tmp', tmp, 'cs', cs, 'par', pa);

        set_param('entrega3E2','SimulationCommand','continue') 

    end
    pause(0.1)
end

