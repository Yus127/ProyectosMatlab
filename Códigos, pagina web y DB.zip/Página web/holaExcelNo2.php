<?php
include_once('pdo.php');
$datosno2 = $pdo->query("SELECT * FROM no2_buena ORDER BY RAND() LIMIT 1");
$response = array();
foreach ($datosno2 as $datono2)
{
    $response[] = array("id"=>intval($datono2['id']),
                       "timestamp"=>($datono2['ts']),
                       "ATI"=>intval($datono2['ATI']),
                       "BJU"=>intval($datono2['BJU']),
                       "CAM"=>intval($datono2['CAM']),
                       "CCA"=>intval($datono2['CCA']),
                       "MON"=>intval($datono2['MON']),
                       "CUT"=>intval($datono2['CUT']),
                       "FAC"=>intval($datono2['FAC']),
                       "FAR"=>intval($datono2['FAR']),
                       "GAM"=>intval($datono2['GAM']),
                       "HGM"=>intval($datono2['HGM']),
                       "IZT"=>intval($datono2['IZT']),
                       "MER"=>intval($datono2['MER']),
                       "MGH"=>intval($datono2['MGH']),
                       "NEZ"=>intval($datono2['NEZ']),
                       "PED"=>intval($datono2['PED']),
                       "SAC"=>intval($datono2['SAC']),
                       "SAG"=>intval($datono2['SAG']),
                       "SFE"=>intval($datono2['SFE']),
                       "TAH"=>intval($datono2['TAH']),
                       "TLA"=>intval($datono2['TLA']),
                       "UAX"=>intval($datono2['UAX']),                       "UIZ"=>intval($datono2['UIZ']),                       "VIF"=>intval($datono2['VIF']));
}

header('Content-Type: application/json');
        echo json_encode($response);
//print_r($response);
exit;
?>
