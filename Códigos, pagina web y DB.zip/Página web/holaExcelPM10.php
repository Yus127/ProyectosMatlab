<?php
include_once('pdo.php');
$datospm10 = $pdo->query("SELECT * FROM pm10_buena ORDER BY RAND() LIMIT 1");
$response = array();
foreach ($datospm10 as $datopm10)
{
    $response[] = array("id"=>intval($datopm10['id']),
                       "timestamp"=>($datopm10['ts']),                       
                       "ATI"=>intval($datopm10['ATI']),
                       "BJU"=>intval($datopm10['BJU']),                         "CAM"=>intval($datopm10['CAM']),
                       "CUT"=>intval($datopm10['CUT']),
                       "FAC"=>intval($datopm10['FAC']),
                       "INN"=>intval($datopm10['INN']),                       
                       "IZT"=>intval($datopm10['IZT']),
                       "MER"=>intval($datopm10['MER']),
                       "PED"=>intval($datopm10['PED']),
                       "SAG"=>intval($datopm10['SAG']),
                       "SFE"=>intval($datopm10['SFE']),
                       "TLA"=>intval($datopm10['TLA']),                       
                       "UIZ"=>intval($datopm10['UIZ']), 
                       "VIF"=>intval($datopm10['VIF']));
}

header('Content-Type: application/json');
        echo json_encode($response);
//print_r($response);
exit;
?>