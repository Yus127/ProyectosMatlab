<?php
include_once('pdo.php');
$datostemp = $pdo->query("SELECT * FROM tmp_buena ORDER BY RAND() LIMIT 1");
$response = array();
foreach ($datostemp as $datotemp)
{
    $response[] = array("id"=>intval($datotemp['id']),
                       "timestamp"=>($datotemp['ts']),                      
                       "BJU"=>intval($datotemp['BJU']),                         
                       "MON"=>intval($datotemp['MON']),
                       "CHO"=>intval($datotemp['CHO']),
                       "CUA"=>intval($datotemp['CUA']),
                       "FAC"=>intval($datotemp['FAC']),
                       "GAM"=>intval($datotemp['GAM']),
                       "INN"=>intval($datotemp['INN']),                       
                       "MER"=>intval($datotemp['MER']),
                       "MGH"=>intval($datotemp['MGH']),
                       "NEZ"=>intval($datotemp['NEZ']),
                       "PED"=>intval($datotemp['PED']),
                       "SAG"=>intval($datotemp['SAG']),
                       "SFE"=>intval($datotemp['SFE']),
                       "SS1"=>intval($datotemp['SS1']),
                       "TAH"=>intval($datotemp['TAH']),                       
                       "TLA"=>intval($datotemp['TLA']), 
                       "UAX"=>intval($datotemp['UAX']),                       "UIZ"=>intval($datotemp['UIZ']),                       "VIF"=>intval($datotemp['VIF']),        
                       "XAL"=>intval($datotemp['XAL']));
}

header('Content-Type: application/json');
        echo json_encode($response);
//print_r($response);
exit;
?>