<?php
//Conexión con PDO
    $user = 'root';
    $pass = '';

    $pdo = new PDO('mysql:host=localhost;dbname=gpo32-e2', $user, $pass);
//Select 
$sql = "INSERT INTO datospackettracer(id, idEstacion, ts, co2, co, t, rh) VALUES (:i, :ie, :t, :co, :c, :te, :r)";
$stmt = $pdo->prepare($sql);
//error_reporting(0);
$stmt->execute(array(
    ':i' => $_POST['id'],
    ':ie' => $_POST['idEstacion'],
    ':t' => $_POST['ts'],
    ':co' => $_POST['co2'],
    ':c' => $_POST['co'],
    ':te' => $_POST['t'],
    ':r' => $_POST['rh'])); 
echo "Que si jale plox";
//print_r($response);
exit;
?>