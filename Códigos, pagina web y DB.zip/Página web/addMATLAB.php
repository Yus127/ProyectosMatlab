<?php
//Conexión con PDO
// NO SE HA CONECTADO MATLAB
    $user = 'root';
    $pass = '';

    $pdo = new PDO('mysql:host=localhost;dbname=gpo32-e2', $user, $pass);
//Select 
$sql = "INSERT INTO datossimulink(id, pm10, pm25, rh, tmp, cs, par) VALUES (:i, :p1, :p2, :r, :tm, :c, :pa)";
$stmt = $pdo->prepare($sql);
//error_reporting(0);
$stmt->execute(array(
    ':i' => $_POST['id'],
    ':p1' => $_POST['pm10'],
    ':p2' => $_POST['pm25'],
    ':r' => $_POST['rh'],
    ':tm' => $_POST['tmp'],
    ':c' => $_POST['cs'],
    ':pa' => $_POST['par'])); 
echo "Otro";
//print_r($response);
exit;
?>