<?php
include_once('pdo.php');
$datosco = $pdo->query("SELECT * FROM co_buena ORDER BY RAND() LIMIT 1");
$response = array();
foreach ($datosco as $datoco)
{
    $response[] = array("id"=>($datoco['id']),
                       "timestamp"=>($datoco['ts']),
                       "ATI"=>($datoco['ATI']),
                       "BJU"=>($datoco['BJU']),
                       "CAM"=>($datoco['CAM']),                         
                       "MON"=>($datoco['MON']),
                       "FAC"=>($datoco['FAC']),
                       "FAR"=>($datoco['FAR']),
                       "HGM"=>($datoco['HGM']),
                       "INN"=>($datoco['INN']),
                       "IZT"=>($datoco['IZT']),                       
                       "LLA"=>($datoco['LLA']),
                       "MER"=>($datoco['MER']),
                       "MGH"=>($datoco['MGH']),
                       "NEZ"=>($datoco['NEZ']),
                       "PED"=>($datoco['PED']),
                       "SAG"=>($datoco['SAG']),
                       "SFE"=>($datoco['SFE']),
                       "TAH"=>($datoco['TAH']),
                       "TLA"=>($datoco['TLA']),
                       "UAX"=>($datoco['UAX']),                       
                       "UIZ"=>($datoco['UIZ']), 
                       "VIF"=>($datoco['VIF']));
}

header('Content-Type: application/json');
        echo json_encode($response);
//print_r($response);
exit;
?>
