<?php include_once('pdo.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Base de Datos</title>
    <style>
        .button{
  border: black;
  background-color: #76E4E0;
  color: black;
  padding: 8px 16px;
  text-align: center;
  text-decoration: underline;
  display: inline-block;
  font-size: 32px;
  margin: 4px 2px;
  transition-duration: 0.4s;
  cursor: pointer;
} 
      body{
        background-color: #76E4E0;
        color:black;
        font-family: fantasy, monospace;
        font-size:20px;
        text-align:center;
        align-content: center;
      }
      </style>
</head>
<body>
    <h1><strong>Calidad del Aire en la CDMX</strong></h1>
    
        <table border="10" cellpadding="10">
            <tr>
                <th>ID</th>
                <th>ID Estación</th>
                <th>Timestamp</th>
                <th>CO2</th>
                <th>CO</th>
                <th>Temperatura</th>
                <th>RH</th>
            </tr>
            
            
            <?php
            $stmt = $pdo->query("SELECT * FROM datospackettracer");
            while ($row = $stmt->fetch()) {
            
            ?>
            
            <tr>
                <th><?php echo $row['id']; ?></th>
                <th><?php echo $row['idEstacion']; ?></th>
                <th><?php echo $row['ts']; ?></th>
                <th><?php echo $row['co2']; ?></th>
                <th><?php echo $row['co']; ?></th>
                <th><?php echo $row['t']; ?></th>
                <th><?php echo $row['rh']; ?></th>
            </tr>
            
            <?php } ?>
                
        </table>
        <br>
        <table border="10" cellpadding="10">
            <tr>
                <th>ID</th>
                <th>PM 10</th>
                <th>PM 25</th>
                <th>RH</th>
                <th>Temperatura</th>
                <th>CheckSum</th>
                <th>Paridad</th>
            </tr>
            
            
            <?php
            $stmt = $pdo->query("SELECT * FROM datossimulink");
            while ($row = $stmt->fetch()) {
            
            ?>
            
            <tr>
                <th><?php echo $row['id']; ?></th>
                <th><?php echo $row['pm10']; ?></th>
                <th><?php echo $row['pm25']; ?></th>
                <th><?php echo $row['rh']; ?></th>
                <th><?php echo $row['tmp']; ?></th>
                <th><?php echo $row['cs']; ?></th>
                <th><?php echo $row['par']; ?></th>
            </tr>
            
            <?php } ?>
                
        </table>
            
        <br>
        <button class="button" onclick="location.href='http://10.48.149.219/Gpo32-E2/index.html';">
        <strong>Regresar a la Página</strong>
        </button>

</body>
</html>