<?php
include_once('pdo.php');
$datosrh = $pdo->query("SELECT * FROM rh_buena ORDER BY RAND() LIMIT 1");
$response = array();
foreach ($datosrh as $datorh)
{
    $response[] = array("id"=>intval($datorh['id']),
                       "timestamp"=>($datorh['ts']),
                       "BJU"=>intval($datorh['BJU']),                         "MON"=>intval($datorh['MON']),
                       "CHO"=>intval($datorh['CHO']),
                       "CUT"=>intval($datorh['CUT']),
                       "FAC"=>intval($datorh['FAC']),
                       "GAM"=>intval($datorh['GAM']),
                       "INN"=>intval($datorh['INN']),                       
                       "MER"=>intval($datorh['MER']),
                       "MGH"=>intval($datorh['MGH']),
                       "NEZ"=>intval($datorh['NEZ']),
                       "PED"=>intval($datorh['PED']),
                       "SAG"=>intval($datorh['SAG']),
                       "SFE"=>intval($datorh['SFE']),
                       "SS1"=>intval($datorh['SS1']),
                       "TAH"=>intval($datorh['TAH']),
                       "TLA"=>intval($datorh['TLA']),                       
                       "UAX"=>intval($datorh['UAX']), 
                       "VIF"=>intval($datorh['VIF']),
                       "XAL"=>intval($datorh['XAL']));
}

header('Content-Type: application/json');
        echo json_encode($response);
//print_r($response);
exit;
?>