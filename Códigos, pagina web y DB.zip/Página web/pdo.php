<?php 

//Conectarse a la DB

    $user = 'root';
    $pass = '';

    $pdo = new PDO('mysql:host=localhost;dbname=gpo32-e2', $user, $pass);