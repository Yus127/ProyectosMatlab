<?php
include_once('pdo.php');
$datosso2 = $pdo->query("SELECT * FROM so2_buena ORDER BY RAND() LIMIT 1");
$response = array();
foreach ($datosso2 as $datoso2)
{
    $response[] = array("id"=>intval($datoso2['id']),
                       "timestamp"=>($datoso2['ts']),                       
                       "ATI"=>intval($datoso2['ATI']),
                       "BJU"=>intval($datoso2['BJU']),                         
                       "CAM"=>intval($datoso2['CAM']),
                       "CCA"=>intval($datoso2['CCA']),
                       "MON"=>intval($datoso2['MON']),
                       "CUT"=>intval($datoso2['CUT']),
                       "FAC"=>intval($datoso2['FAC']),
                       "FAR"=>intval($datoso2['FAR']),
                       "HGM"=>intval($datoso2['HGM']),
                       "INN"=>intval($datoso2['INN']),                       
                       "IZT"=>intval($datoso2['IZT']),
                       "LLA"=>intval($datoso2['LLA']),
                       "MER"=>intval($datoso2['MER']),
                       "MGH"=>intval($datoso2['MGH']),
                       "NEZ"=>intval($datoso2['NEZ']),
                       "PED"=>intval($datoso2['PED']),
                       "SFE"=>intval($datoso2['SFE']),
                       "TAH"=>intval($datoso2['TAH']),
                       "TLA"=>intval($datoso2['TLA']),
                       "UAX"=>intval($datoso2['UAX']),                       
                       "UIZ"=>intval($datoso2['UIZ']), 
                       "VIF"=>intval($datoso2['VIF']));
}

header('Content-Type: application/json');
        echo json_encode($response);
//print_r($response);
exit;
?>
