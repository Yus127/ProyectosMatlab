<?php
include_once('pdo.php');
$datosmat = $pdo->query("SELECT * FROM datossimulink ORDER BY id DESC LIMIT 1");
$response = array();
foreach ($datosmat as $datomat)
{
    $response[] = array("id"=>intval($datomat['id']),
                       "pm10"=>intval($datomat['pm10']),
                       "pm25"=>intval($datomat['pm25']),
                       "Humedad"=>intval($datomat['rh']),
                       "Temperatura"=>intval($datomat['tmp']),
                       "CheckSum"=>intval($datomat['cs']),
                       "Paridad"=>intval($datomat['par']));
}
header('Content-Type: application/json');
echo json_encode($response);
//print_r($response);
exit;
?>
