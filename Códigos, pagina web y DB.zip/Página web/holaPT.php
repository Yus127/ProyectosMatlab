<?php
include_once('pdo.php');
$datospt = $pdo->query("SELECT * FROM datospackettracer ORDER BY id DESC LIMIT 1");
$response = array();
foreach ($datospt as $datopt)
{
    $response[] = array("id"=>intval($datopt['id']),
                       "idEstacion"=>intval($datopt['idEstacion']),
                       "timestamp"=>($datopt['ts']),
                       "co2"=>intval($datopt['co2']),
                       "co"=>intval($datopt['co']),
                       "temp"=>intval($datopt['t']),
                       "rh"=>intval($datopt['rh']));
}
header('Content-Type: application/json');
echo json_encode($response);
//print_r($response);
exit;
?>

