<?php
include_once('pdo.php');
$datoswsp = $pdo->query("SELECT * FROM wsp_buena ORDER BY RAND() LIMIT 1");
$response = array();
foreach ($datoswsp as $datowsp)
{
    $response[] = array("id"=>intval($datowsp['id']),
                       "timestamp"=>($datowsp['ts']),                         
                       "AJM"=>intval($datowsp['AJM']),                     
                       "BJU"=>intval($datowsp['BJU']),                         
                       "MON"=>intval($datowsp['MON']),
                       "CHO"=>intval($datowsp['CHO']),
                       "CUT"=>intval($datowsp['CUT']),
                       "FAC"=>intval($datowsp['FAC']),                      
                       "FAR"=>intval($datowsp['FAR']),
                       "GAM"=>intval($datowsp['GAM']),
                       "INN"=>intval($datowsp['INN']),                       
                       "MER"=>intval($datowsp['MER']),
                       "NEZ"=>intval($datowsp['NEZ']),
                       "PED"=>intval($datowsp['PED']),
                       "SAG"=>intval($datowsp['SAG']),
                       "TAH"=>intval($datowsp['TAH']),                       
                       "TLA"=>intval($datowsp['TLA']), 
                       "UAX"=>intval($datowsp['UAX']),                       "UIZ"=>intval($datowsp['UIZ']),                       "VIF"=>intval($datowsp['VIF']),        
                       "XAL"=>intval($datowsp['XAL']));
}

header('Content-Type: application/json');
        echo json_encode($response);
//print_r($response);
exit;
?>