<?php
include_once('pdo.php');
$datoso3 = $pdo->query("SELECT * FROM o3_buena ORDER BY RAND() LIMIT 1");
$response = array();
foreach ($datoso3 as $datoo3)
{
    $response[] = array("id"=>intval($datoo3['id']),
                       "timestamp"=>($datoo3['ts']),
                       "ATI"=>intval($datoo3['ATI']),
                       "BJU"=>intval($datoo3['BJU']),
                       "CAM"=>intval($datoo3['CAM']),
                       "CCA"=>intval($datoo3['CCA']),
                       "CUT"=>intval($datoo3['CUT']),
                       "FAC"=>intval($datoo3['FAC']),
                       "FAR"=>intval($datoo3['FAR']),
                       "GAM"=>intval($datoo3['GAM']),
                       "HGM"=>intval($datoo3['HGM']),
                       "IZT"=>intval($datoo3['IZT']),                       
                       "LLA"=>intval($datoo3['LLA']),
                       "MER"=>intval($datoo3['MER']),
                       "MGH"=>intval($datoo3['MGH']),
                       "NEZ"=>intval($datoo3['NEZ']),
                       "PED"=>intval($datoo3['PED']),
                       "SAC"=>intval($datoo3['SAC']),
                       "SAG"=>intval($datoo3['SAG']),
                       "SFE"=>intval($datoo3['SFE']),
                       "TAH"=>intval($datoo3['TAH']),
                       "TLA"=>intval($datoo3['TLA']),
                       "UAX"=>intval($datoo3['UAX']),                       
                       "UIZ"=>intval($datoo3['UIZ']), 
                       "VIF"=>intval($datoo3['VIF']));
}

header('Content-Type: application/json');
        echo json_encode($response);
//print_r($response);
exit;
?>
