<?php
include_once('pdo.php');
$datospm25 = $pdo->query("SELECT * FROM pm25_buena ORDER BY RAND() LIMIT 1");
$response = array();
foreach ($datospm25 as $datopm25)
{
    $response[] = array("id"=>intval($datopm25['id']),
                       "timestamp"=>($datopm25['ts']),                       
                       "BJU"=>intval($datopm25['BJU']),                         
                       "CAM"=>intval($datopm25['CAM']),
                       "CCA"=>intval($datopm25['CCA']),
                       "FAR"=>intval($datopm25['FAR']),
                       "INN"=>intval($datopm25['INN']),                       
                       "MER"=>intval($datopm25['MER']),
                       "NEZ"=>intval($datopm25['NEZ']),
                       "PED"=>intval($datopm25['PED']),
                       "SAC"=>intval($datopm25['SAC']),               
                       "SAG"=>intval($datopm25['SAG']),
                       "SFE"=>intval($datopm25['SFE']),
                       "TLA"=>intval($datopm25['TLA']),
                       "UAX"=>intval($datopm25['UAX']),                       
                       "UIZ"=>intval($datopm25['UIZ']));
}

header('Content-Type: application/json');
        echo json_encode($response);
//print_r($response);
exit;
?>